/*
 * ---------------------------
 * CP264: Spring 2018
 * Graphs (Adjacency Matrix)
 * Header File
 * Author: Qutaiba Albluwi
 * ---------------------------
 */

/*
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Course:  CP264 Spring 2018
Category: Assignment 10
-------------------------------------------------------
*/


# include <stdio.h>
# include <stdlib.h>
# include <assert.h>
# include <string.h>
# include "graphs_AM.h"

GraphAM* create_graph_AM(){
	GraphAM* g = (GraphAM*)malloc(sizeof(GraphAM));
	g->matrix = (int**)malloc(sizeof(int*)*2); //create 2x2 matrix
	g->matrix[0] = (int*)malloc(sizeof(int)*2);
	g->matrix[1] = (int*)malloc(sizeof(int)*2);
	g->matrix[0][0] = -1;
	g->matrix[0][1] = -1;
	g->matrix[1][0] = -1;
	g->matrix[1][1] = -1;
	g->vertexList = (Vertex*)malloc(sizeof(Vertex));
	g->vertexCount = 0;
	g->edgeCount = 0;
	return g;\
}

void destroy_graph_AM(GraphAM** g){
	int rows = (*g)->vertexCount;
	(*g)->vertexCount = 0;
	(*g)->edgeCount = 0;
	free((*g)->vertexList);
	(*g)->vertexList = NULL;
	int i;
	for(i=rows-1;i>=0;i--){
		free((*g)->matrix[i]);
		(*g)->matrix[i] = NULL;
	}
	free((*g)->matrix);
	(*g)->matrix = NULL;
	free(*g);
	*g = NULL;
	return;
}

int isNull_graph_AM(GraphAM* g){
	assert(g!=NULL);
	if(g->edgeCount == 0 && g->vertexCount == 0)
		return True;
	return False;
}

int isEmpty_graph_AM(GraphAM* g){
	assert(g!=NULL);
	if(g->edgeCount == 0)
		return True;
	return False;
}

void print_graph_AM(GraphAM* g){
	assert(g!=NULL);
	int i,j;
	printf("(Adjacency Matrix Representation): #Vertices = %d, #Edges = %d\n",
			g->vertexCount,g->edgeCount);
	if(isNull_graph_AM(g))
		printf("<null graph>\n");
	else if(g->vertexCount == 1){
		printf("Single Vertex graph:\n");
		printf("%d\n",g->matrix[0][0]);
		printf("\n");
	}
	else{
		printf("Adjacency Matrix:\n");
		for(i=0;i<g->vertexCount;i++){
			for(j=0;j<g->vertexCount;j++)
				printf("%5d",g->matrix[i][j]);
			printf("\n");
		}
	}
	return;
}

int addVertex_graph_AM(GraphAM* g, Vertex* v){
	assert(g!=NULL);
	assert(v!=NULL);
	int success = 0;

	if(findVertex_graph_AM(g,v) == -1){ //vertex is not found
		//increase size of vertexList
		if(g->vertexCount>0)
			g->vertexList = realloc(g->vertexList, sizeof(Vertex)*(g->vertexCount+1));
		//force vertices to be numbered sequentially
		if(v->num != g->vertexCount)
			v->num = g->vertexCount;
		//add vertex to vertexList
		g->vertexList[g->vertexCount] = *v;
		g->vertexCount++;
		success = 1;
		//re-adjust size of adjacency matrix
		int i;
		if(g->vertexCount>2){
			//increment #rows
			g->matrix = realloc(g->matrix,sizeof(int*)*g->vertexCount);
			//increment #columns for each row
			for(i=0;i<g->vertexCount-1;i++){
				g->matrix[i]=realloc(g->matrix[i],sizeof(int)*g->vertexCount);
				g->matrix[i][g->vertexCount-1] = -1;
			}
			g->matrix[g->vertexCount-1]= (int*)malloc(sizeof(int)*g->vertexCount);
			for(i=0;i<g->vertexCount;i++)
				g->matrix[g->vertexCount-1][i]=-1;
		}
	}
	else //vertex already exist
		printf("Error (addVertex_graph_AM): vertex already exist!\n");
	return success;
}

int findVertex_graph_AM(GraphAM* g, Vertex* v){
	assert(g!=NULL);
	assert(v!=NULL);
	//only compares vertex names, because vertex numbering is enforced sequentially
	int i;
	if(strcmp(v->name,"")==0)
		return -1;		//if vertex has no name, return not found
	for(i=0;i<g->vertexCount;i++)
		if(strcmp(v->name,g->vertexList[i].name)==0)
			return i;
	return -1; //not found
}

//if an edge already exist, it is replaced
int addEdge_graph_AM(GraphAM* g, Edge* e){
	int success = 0;
	int v1_index = findVertex_graph_AM(g,e->v1);
	if (v1_index == -1 && e->v1->num >= g->vertexCount){
		addVertex_graph_AM(g,e->v1);
		v1_index = g->vertexCount-1;
	}
	else
		v1_index = e->v1->num;

	int v2_index = findVertex_graph_AM(g,e->v2);
	if (v2_index == -1 && e->v2->num >= g->vertexCount){
		addVertex_graph_AM(g,e->v2);
		v2_index = g->vertexCount-1;
	}
	else
		v2_index = e->v2->num;

	if(e->direction == 1 || e->direction == 0)
		g->matrix[v1_index][v2_index]=e->weight;
	else if (e->direction == -1)
		g->matrix[v2_index][v1_index]=e->weight;
	else if (e->direction == 2){
		g->matrix[v1_index][v2_index]=e->weight;
		g->matrix[v2_index][v1_index]=e->weight;
		g->edgeCount++;
	}
	success = 1;
	g->edgeCount++;

	return success;
}

int removeEdge_graph_AM(GraphAM* g, Edge* e){
	//Put your solution to Task 2 here
	return 1;
}

int removeVertex_graph_AM(GraphAM* g, Vertex* v){
	//Put your solution to Task 3 here
	return 1;
}

//assumes directed weighted graph
int findpath_graph_AM(GraphAM* g, Vertex* v1, Vertex* v2){
	int cost = 0;
	//Put your solution to Task 4 here
	return cost;
}
